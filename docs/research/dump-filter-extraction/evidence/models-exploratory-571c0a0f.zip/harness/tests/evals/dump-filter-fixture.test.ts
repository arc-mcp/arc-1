import { expect, it } from 'vitest';
import { createWorld } from './diagnostic-value/world.js';
import { cases, grade } from './diagnostic-value/cases.js';
import { parseDumpList } from '../../src/adt/diagnostics.js';
async function ids(query: string) {
  const world = createWorld('dumps-target'); const response = await world.fetch(`https://offline.invalid/sap/bc/adt/runtime/dumps?${query}`);
  expect(world.unsupported).toEqual([]); return parseDumpList(await response.text()).map(d => d.id);
}
it('includes wrong-day controls when bounds are omitted', async () => {
  expect((await ids('$query=and(equals(runtimeError,TIME_OUT))')).sort()).toEqual(['D079','D113','D900','D901']);
});
it('respects time bounds before selecting filtered rows', async () => {
  expect(await ids('from=20261017000000&to=20261017235959&$query=and(equals(runtimeError,TIME_OUT))')).toEqual(['D079','D113']);
});
it('keeps the legacy scan a fair successful alternative', async () => {
  const found = await ids('from=20261017000000&to=20261017235959&$top=100');
  expect(found[0]).toBe('D000'); expect(found).toContain('D079'); expect(found).not.toContain('D900');
});
it('does not award success for wrong-day answers or unsupported guesses', () => {
  const task=cases[4]; const trace=[{ name:'SAPDiagnose', arguments:{action:'dumps'}, result:'[{"id":"D079"},{"id":"D113"},{"id":"D900"}]',isError:false }];
  expect(grade(task, '{"dumpIds":["D079","D113"]}',trace).completed).toBe(true);
  expect(grade(task, '{"dumpIds":["D900","D079"]}',trace).completed).toBe(false);
  expect(grade(task, '{"dumpIds":["D079","D113"]}',[]).completed).toBe(false);
  expect(grade(task, 'D079 and D113',trace).format).toBe('invalid');
});
