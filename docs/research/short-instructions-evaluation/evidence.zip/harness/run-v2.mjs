import fs from 'node:fs';
import path from 'node:path';
import { spawn, execFileSync } from 'node:child_process';
import crypto from 'node:crypto';
import { cases, common, instructions, tools, catalog, respond, root } from './fixture-v2.mjs';
const [provider, output, repeatsArg = '3', selected = ''] = process.argv.slice(2);
if (!['codex', 'ollama'].includes(provider) || !output) throw new Error('run.mjs codex|ollama NEW_OUTPUT_DIR [REPEATS] [CASE_ID]');
fs.mkdirSync(output, { mode: 0o700 });
const model = provider === 'codex' ? 'gpt-5.6-sol' : 'qwen3.6:35b-mlx';
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const manifest = { provider, model, selected, repeats: Number(repeatsArg), commit: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding:'utf8'}).trim(), created: new Date().toISOString(), fixture: 'Synthetic, offline; no SAP access', catalogHash: sha(JSON.stringify(catalog)), instructionChars: Object.fromEntries(Object.entries(instructions).map(([k,v]) => [k,v.length])), instructions, common, cases, settings: provider === 'codex' ? { reasoning:'medium', cli:'0.144.0', maxCalls:8, timeoutMs:240000 } : { think:false, temperature:0.2, num_ctx:32768, num_predict:3000, seeds:[9571,9572,9573], maxCalls:8, timeoutMs:180000 }, codeHashes:Object.fromEntries(['fixture-v2.mjs','run-v2.mjs'].map(f=>[f,sha(fs.readFileSync(new URL(f, import.meta.url)))])) };
if (provider === 'ollama') {
  manifest.installedModels = await (await fetch('http://localhost:11434/api/tags')).json();
  manifest.ollamaVersion = await (await fetch('http://localhost:11434/api/version')).json();
}
fs.writeFileSync(path.join(output,'manifest.json'), JSON.stringify(manifest,null,2));
const summaries=[];
async function codexRun(mode, task, base) {
  const traceFile = base+'.trace.jsonl';
  const args=['exec','--ignore-user-config','--ignore-rules','--skip-git-repo-check','--ephemeral','-C','/tmp/arc1-957-eval/empty','--sandbox','read-only','-m',model,'--json','-o',base+'.answer.txt'];
  const config={project_doc_max_bytes:0, model_reasoning_effort:'medium', web_search:'disabled', developer_instructions:common, 'mcp_servers.fixture.command':process.execPath, 'mcp_servers.fixture.args':[path.resolve('/tmp/arc1-957-eval/fixture-v2.mjs'),'serve',mode,traceFile], 'mcp_servers.fixture.required':true};
  for (const key of ['shell_tool','apps','multi_agent','plugins','hooks','browser_use','browser_use_external','in_app_browser','computer_use','image_generation','memories','goals','workspace_dependencies']) config[`features.${key}`]=false;
  for (const [key,val] of Object.entries(config)) args.push('-c',`${key}=${JSON.stringify(val)}`);
  args.push('-');
  const stdout=fs.openSync(base+'.events.jsonl','w');
  const stderr=fs.openSync(base+'.stderr','w');
  const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>!k.startsWith('CODEX_THREAD')&&!/^(SAP_|TEST_SAP_|ARC1_)/.test(k)));
  const child=spawn('/Users/marianzeis/.nvm/versions/node/v22.21.1/bin/codex',args,{cwd:'/tmp/arc1-957-eval/empty',env,stdio:['pipe',stdout,stderr],detached:true});
  let timedOut=false;
  const timer=setTimeout(()=>{timedOut=true;process.kill(-child.pid,'SIGTERM');},240000);
  child.stdin.end(task.prompt);
  const code=await new Promise((resolve,reject)=>{child.on('exit',resolve);child.on('error',reject)});
  clearTimeout(timer);fs.closeSync(stdout);fs.closeSync(stderr);
  const readJsonLines=file=>fs.existsSync(file)?fs.readFileSync(file,'utf8').trim().split('\n').filter(Boolean).map(l=>JSON.parse(l)):[];
  const events=readJsonLines(base+'.events.jsonl');
  return { final:fs.existsSync(base+'.answer.txt')?fs.readFileSync(base+'.answer.txt','utf8'):'', calls:readJsonLines(traceFile), usage:events.findLast(e=>e.type==='turn.completed')?.usage, error:timedOut?'timeout':code!==0?`exit ${code}`:undefined, foreignTools:events.filter(e=>e.item&&['command_execution','web_search'].includes(e.item.type)) };
}
async function ollamaRun(mode,task,repeat) {
  const messages=[{role:'system',content:common+'\n\n'+instructions[mode]},{role:'user',content:task.prompt}];
  const calls=[],turns=[];
  let final='',error;
  try {
    for(let i=0;i<9;i++){
      const response=await fetch('http://localhost:11434/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,messages,tools,stream:false,think:false,keep_alive:'15m',options:{temperature:0.2,seed:9571+repeat,num_ctx:32768,num_predict:3000}}),signal:AbortSignal.timeout(180000)});
      if(!response.ok)throw new Error(`Ollama ${response.status}: ${await response.text()}`);
      const turn=await response.json();turns.push(turn);messages.push(turn.message);
      if(turn.done_reason==='length')throw new Error('Output token limit reached');
      const requested=turn.message.tool_calls??[];
      if(!requested.length){final=turn.message.content??'';break;}
      for(const call of requested){
        const name=call.function.name;
        const args=typeof call.function.arguments==='string'?JSON.parse(call.function.arguments):call.function.arguments;
        const result=calls.length<8?respond(name,args):{isError:true,content:[{type:'text',text:'Evaluation tool-call limit exceeded. Finish with the evidence already obtained.'}]};
        calls.push({name,args,result});messages.push({role:'tool',tool_name:name,content:result.content.map(c=>c.text).join('\n')});
      }
      if(calls.length>8)throw new Error('Tool-call limit exceeded');
    }
    if(!final)throw new Error('No final answer');
  }catch(e){error=String(e);}
  return {final,calls,turns,error,usage:{input_tokens:turns.reduce((n,t)=>n+(t.prompt_eval_count??0),0),output_tokens:turns.reduce((n,t)=>n+(t.eval_count??0),0),first_input_tokens:turns[0]?.prompt_eval_count,max_input_tokens:Math.max(0,...turns.map(t=>t.prompt_eval_count??0))}};
}
for(let repeat=0;repeat<Number(repeatsArg);repeat++){
  for(const [index,task] of cases.entries()){
    if(selected&&!selected.split(',').includes(task.id))continue;
    for(const mode of ((repeat+index)%2===0?['full','short']:['short','full'])){
      const started=Date.now(), id=`${repeat+1}-${task.id}-${mode}`,base=path.join(output,id);
      let result;
      try{result=provider==='codex'?await codexRun(mode,task,base):await ollamaRun(mode,task,repeat);}catch(e){result={final:'',calls:[],error:String(e)}}
      const summary={id,provider,model,repeat:repeat+1,task:task.id,mode,complete:!!result.final&&!result.error,error:result.error,calls:result.calls.length,toolErrors:result.calls.filter(c=>c.result.isError).length,usage:result.usage,durationMs:Date.now()-started};
      fs.writeFileSync(base+'.json',JSON.stringify({summary,prompt:task.prompt,...result},null,2));
      summaries.push(summary);fs.writeFileSync(path.join(output,'summary.json'),JSON.stringify(summaries,null,2));console.log(JSON.stringify(summary));
    }
  }
}
