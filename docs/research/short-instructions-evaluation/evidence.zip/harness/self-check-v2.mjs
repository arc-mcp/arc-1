import assert from 'node:assert/strict';
import fs from 'node:fs';
import {catalog,cases,instructions,respond} from './fixture-v2.mjs';
const text = (name,args) => {const r=respond(name,args);assert.ok(!r.isError,JSON.stringify({name,args,r}));return r.content[0].text};
assert.equal(cases.length,8);assert.equal(new Set(cases.map(c=>c.id)).size,8);assert.equal(catalog.length,9);
assert.equal(instructions.full.length-instructions.short.length,1696);
for(const include of ['main','MAIN'])assert.match(text('SAPRead',{type:'CLAS',name:'ZCL_EVAL_FEE',include}),/iv_amount < 0/);
assert.doesNotMatch(text('SAPRead',{type:'CLAS',name:'ZCL_EVAL_FEE',version:'inactive'}),/iv_amount < 0/);
assert.match(text('SAPRead',{type:'CLAS',name:'ZCL_EVAL_FEE',action:'diff',from:'active',to:'inactive'}),/-.*iv_amount < 0/);
assert.match(text('SAPRead',{type:'CLAS',name:'ZCL_EVAL_FEE',method:'CALCULATE',includeSignature:true}),/RAISING cx_sy_illegal_argument/);
assert.equal(text('SAPRead',{type:'CLAS',name:'ZCL_EVAL_FEE',grep:'TEST.*FOR'}),'0 matches.');
assert.match(text('SAPRead',{type:'CLAS',name:'ZCL_EVAL_FEE',grep:'rv_fee ='}),/0.02/);
assert.match(text('SAPContext',{type:'CLAS',name:'ZCL_EVAL_FEE'}),/minimum fee of 10/);
assert.doesNotMatch(text('SAPContext',{type:'CLAS',name:'ZCL_EVAL_FEE',includeKtd:false}),/minimum fee/);
assert.doesNotMatch(text('SAPContext',{type:'CLAS',name:'ZCL_EVAL_LEGACY_FEE'}),/minimum fee|Knowledge Transfer/);
assert.ok(respond('SAPRead',{type:'SKTD',name:'ZCL_EVAL_LEGACY_FEE'}).isError);
assert.equal(JSON.parse(text('SAPSearch',{query:'ZCL_EVAL_FEE*'}))[0].objectName,'ZCL_EVAL_FEE');
assert.deepEqual(JSON.parse(text('SAPSearch',{query:'*TEST*'})),[]);
for(const maxResults of [undefined,1,3,5,100]){
 const args={name:'ZCL_EVAL_FEE',type:'CLAS',...(maxResults?{maxResults}:{})};
 const a=JSON.parse(text('SAPNavigate',{...args,action:'references'}));
 const b=JSON.parse(text('SAPContext',{...args,action:'usages'}));
 assert.deepEqual(a.references,b.usages);assert.equal(a.total,b.usageCount);assert.equal(a.total,20);assert.ok(a.truncated);assert.equal(a.shown,Math.min(maxResults??3,3));
}
assert.ok(JSON.parse(text('SAPRead',{type:'SYNTAX',objectType:'CLAS',name:'ZCL_EVAL_FEE'})).checked);
assert.ok(JSON.parse(text('SAPDiagnose',{action:'syntax',type:'CLAS',name:'ZCL_EVAL_FEE'})).checked);
assert.equal(JSON.parse(text('SAPDiagnose',{action:'syntax',objects:[{type:'CLAS',name:'ZCL_EVAL_FEE'}]})).results[0].status,'passed');
assert.ok(respond('SAPDiagnose',{action:'atc',type:'CLAS',name:'ZCL_EVAL_FEE'}).isError);
assert.equal(JSON.parse(text('SAPDiagnose',{action:'unittest',type:'CLAS',name:'ZCL_EVAL_FEE'})).total,0);
assert.match(text('SAPRead',{type:'PROG',name:'ZEVAL_A'}),/zcl_eval_fee/);
assert.ok(respond('SAPRead',{type:'CLAS',name:'MISSING'}).isError);
assert.ok(respond('SAPWrite',{action:'update'}).isError);
let calls=0;
for(const folder of ['codex-a','codex-b','ollama'])for(const name of fs.readdirSync('/tmp/arc1-957-eval/'+folder).filter(n=>/^[123]-.*\.json$/.test(n))){
 for(const c of JSON.parse(fs.readFileSync('/tmp/arc1-957-eval/'+folder+'/'+name)).calls){
  calls++;assert.doesNotMatch(respond(c.name,c.args).content[0].text,/^No response is recorded/);
 }
}
console.log(`Fixture/surface/alternate-route checks passed; ${calls} exploratory calls replayed without fixture gaps. No model or SAP call.`);
