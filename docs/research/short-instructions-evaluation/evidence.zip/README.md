# Short-instructions evaluation evidence

Measured ARC-1 runtime: a58a364c52f5263b6cc840c7c3fa142f74be3f88 (PR #1117).
Collection: October 27 and infrastructure retries October 29, 2026.

## Contents

- `runs/`: 96 scored conversations, with prompts, final answers and tool responses. Synthetic SAP objects only. No model private reasoning is included.
- `excluded-client-policy/`: all 18 original Codex sessions from the three replaced task cells, with completed MCP client events. Sixteen had calls cancelled by the client; both modes of each affected cell were repeated. These are not scored.
- `grades.json`: per-answer blinded Claude grade, final adjudication and reason. C is core correctness; E is supporting evidence. Passing C does not certify compilable ABAP snippets.
- `summary.json`: per-task counts, budgets, context and tool-call observations.
- `manifests/` and `surface.json`: settings, exact instruction text, catalog and prompts. Only the tested Ollama model metadata is included.
- `harness/`: the original fixture/runner, self-check, frozen hashes and grading rubric. `runtime-schema-audit.json` records two rejected unit-test batch calls; ATC batches pass the runtime schema and their handler support was checked separately. Runtime paths in these scripts refer to the original local machine.
- `reviews/`: plan review and disposition; the final report describes review limitations.

## Reproduce

Check out the measured ARC-1 commit, run `npm ci` and `npm run build`, and make the recorded models available. Adjust the repository, Node, Codex and output paths in the harness for the host. The fixture uses ARC-1 built instruction/catalog functions and its MCP SDK, and has no SAP transport. Run its self-check before the model comparisons.

Use run-v2.mjs for Ollama. For Codex use run-v3.mjs: its per-tool approval override applies only to SAPDiagnose on this offline fixture. Do not apply this evaluation configuration to a live SAP server. The original Codex v2 approval setup was an infrastructure error.

Both runners take provider, new output directory, repetition count, and optional comma-separated task names. Use three repetitions of all eight tasks per mode. Hosted output is stochastic and no seed is controlled for Codex. Exact answers will differ. The fixture deliberately offers only a small set of synthetic facts; it is not a live SAP compatibility benchmark.

Raw exploratory outputs and complete execution logs remain in the local evidence directory, separately from scored data. The archive retains the original excluded client-policy sessions so their replacement is auditable. No production source or schemas were modified by this evaluation.
