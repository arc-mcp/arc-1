**Verdict: not ready to freeze yet.** The overall design is sound: paired arms, frozen artifacts, controls, and limited claims. But five blockers need fixing first, and none of them requires changing the feature or adding runs.

I only saw `plan.md` and `rubric.md`. The prompts, fixture data, instruction texts and harness weren't available, and #3 and #4 depend on them. Also check that the prompts for tasks 2–4, 6 and 7 don't name the behavior being tested (e.g. "check the KTD"). If they do, both arms will behave the same by construction.

### Blockers (fix before the scored manifest and hashes)

1. **Nobody has checked that Codex delivers the instructions** (`/tmp/arc1-957-eval/plan.md:5-6`).
   - Nothing confirms that Codex puts the server's `initialize.instructions` into the model input, and MCP clients handle this differently. If Codex drops it, the Codex half compares two identical prompts.
   - In the pilot, capture the first model request for each arm. Check that the instruction text is present and differs by arm. Check that the tool list is identical across arms and contains only the fixture MCP tools, with no shell, patch or file tools.
   - Keep the model's cwd outside `/tmp/arc1-957-eval`, because `empty/` sits next to `rubric.md`.
   - Quick check: the difference in first-request input tokens between arms should roughly equal tokens(full) − tokens(short).
   - Also confirm that short mode changes only `instructions`. If it also shortens tool descriptions, an identical catalog isn't what ships.

2. **Ollama truncation would hit the full arm harder** (`/tmp/arc1-957-eval/plan.md:5`).
   - If `num_ctx` isn't set explicitly, full instructions + catalog + up to 8 tool results can exceed the default. Ollama may then truncate without returning an API error, and the longer full arm loses more.
   - Set `num_ctx` with room for the longest full-arm run and check the server log for truncation warnings.
   - Set `num_predict`, record `done_reason`, and verify that `think:false` actually took effect.

3. **The "unsupported error for unmatched arguments" rule favors full's route** (`/tmp/arc1-957-eval/plan.md:7`, contradicts `:9`).
   - Any valid call the fixture author didn't anticipate fails artificially. Examples: where-used with a different `maxResults`, SAPContext for task 8, a method read instead of a class read. That rewards following full's prescribed route through the fixture instead of the grader.
   - List the valid argument variants per task from the tool schemas and from both arms' pilot traces, and answer them consistently with the case facts.
     - For task 6, truncate on the server side: any request for 3 or more rows gets the same 3 rows plus "20 total".
     - Unknown objects should get ARC-1's real not-found error.
   - Then freeze.

4. **The rubric mixes correctness with workflow, which contradicts `plan.md:9`** (`/tmp/arc1-957-eval/rubric.md:3,9,10,13`).
   - Pass requires route steps that the correct answer doesn't depend on:
     - task 3 requires a requirements read, but the regression is visible from the active/inactive diff alone;
     - task 4 requires the lookup;
     - task 7 requires attempting all three checks, which is valid only if the prompt asks for all three.
   - Split each task into C (facts in the final answer, no fabrication) and E (evidence calls in the trace).
   - Report C as the headline count. Put E, budget, efficiency and word count in separate columns.
   - Move any criterion whose only justification is the full-instruction text into E.

5. **There is no rule for infrastructure failures in scored runs** (`/tmp/arc1-957-eval/plan.md:8`, `rubric.md:3`).
   - The rubric counts an infra failure as a fail, and the plan only excludes infra failures from the pilot. With 3 runs per cell, one 429 or harness crash flips a cell.
   - Predeclare three things:
     - which failures count as infra: harness error, provider 5xx/429, a fixture gap per #3, out-of-memory or truncation;
     - which count as model failures: looping until timeout or `num_predict`, malformed tool calls, no final answer;
     - the timeout value.
   - Classify failures without seeing the arm label, rerun infra failures once, and keep both attempts in the record.

### Should fix (cheap)

6. **Blinding leaks** (`/tmp/arc1-957-eval/plan.md:8,10`).
   - Prompt-token counts, instruction hashes, durations and timestamps all reveal the arm. Remove them from the grading packet and shuffle the order.
   - "Ambiguous grading" isn't defined, and the person choosing which cases count as ambiguous isn't blind to the arm. Have Opus grade all 96 answers blind and report how often the two graders agree.

7. **Predeclare the decision rule** (`/tmp/arc1-957-eval/plan.md:10,12`).
   - "Based on results, keep full recommended" reads like a conclusion fixed in advance. Say explicitly that full stays the default as a product decision.
   - Then predeclare:
     - **Comparison unit:** the (model, task) cell, comparing passes out of 3 per arm. Codex has no seed, so pairing runs by repetition number is arbitrary; use seed-matched pairs only for Ollama.
     - **What counts as a difference:** a gap of at least 2 out of 3, or a gap in the same direction for both models.
     - **Which tasks back which short use case:** document a use case only if those tasks show no short-only core failure or fabrication. Word it as "no regression observed in N runs", not "qualified".

8. **Token metrics** (`/tmp/arc1-957-eval/plan.md:5,11`).
   - Use the input tokens of the first request. Turn totals grow with the number of tool calls.
   - Ollama's `prompt_eval_count` can leave out tokens reused from the cache, so count tokens offline from the captured prompts.
   - State that temperature and seeds apply only to Ollama.

9. **Define the call budget** (`/tmp/arc1-957-eval/plan.md:8`).
   - Say what counts toward the 8 calls: failed calls? Codex built-in tools like `update_plan`?
   - Say whether call 9 and later are blocked or just graded afterwards, and apply the same rule to both arms.

10. **Pin down rubric ambiguities.**
    - State the target class for each task, and which class the inactive draft belongs to.
    - Task 8 should also accept signatures obtained via SAPContext, since `rubric.md:5` says Context includes them.
    - Task 2: does the boundary test have to be exactly 500, or do 499/501 pass?
    - Task 6: is "3 entries" a limit on the call argument or on the answer content?
    - Add to the manifest: Codex CLI version and model string, Ollama version, model digest and quantization, all options including the Modelfile sampling defaults, and the harness wrapper prompt.

**No change needed:**
- balanced run order;
- methodology changes after the pilot are fixed before the manifest;
- separate failure categories;
- no universal percentage or significance claims;
- timing reported as observational only;
- the scope disclaimers.