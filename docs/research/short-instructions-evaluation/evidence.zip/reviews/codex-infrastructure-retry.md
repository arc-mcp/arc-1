# Codex client-policy retry, 2026-10-29

The first final batch used the read-only sandbox without an MCP tool approval override. Client events show 16 of 48 sessions had SAPDiagnose calls cancelled by the client before reaching the fixture. The human did not cancel these calls. This affected draft-review, supplied-requirements and checks; the other five tasks (30 sessions) had no client-call errors. Server-only traces were incomplete evidence for blocked calls.

Apply the predefined infrastructure retry to both modes of all three affected task cells, all three repetitions (18 sessions). Retain all original outputs and exclude those three original cells from comparative scoring. Do not select retries based on correctness. The two unaffected members of these cells are replaced too, to keep one runtime configuration per cell. No Ollama sessions are repeated.

Only client configuration changes: strict config validation plus per-tool approval_mode=approve for SAPDiagnose on the synthetic fixture. This override is scoped to the spawned CLI; no user configuration, production tool annotations, SAP credentials, or sandbox permissions are changed. An earlier isolated pilot confirmed a successful syntax response. The fixture has no SAP/network implementation. Capture completed MCP events in addition to server traces; verify no cancelled calls or foreign tools remain.

The fixture, user prompts, instructions, task facts and grading rubric are unchanged. run-v3.mjs records its hash. Retain the complete original client event logs; Codex pre-retry grades for the replaced cells are invalid and unused. No second quality retry will be made.
